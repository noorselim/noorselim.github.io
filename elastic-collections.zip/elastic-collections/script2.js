// console.log("Is our script file working?");

// load the airtable library, call it "Airtable";
var Airtable = require("airtable");
// console.log(Airtable);

let container = document.querySelector(".container");

// use airtable library, connect to our base using API key
var base = new Airtable({ apiKey: "keyxStF6a7ua6nohh" }).base(
  "apps9dVh6IY4JNB6Z"
);

// get our collection base, select all the records
// specify functions that will receive the data
base("moviebase")
  .select({}).eachPage(gotPageOfMovies, gotAllMovies);

// an empty array to hold our data
var movies = [];

// callback function that receives our data
function gotPageOfMovies(records, fetchNextPage) {
  console.log("gotPageOfMovies()");
  // add the records from this page to our array
  movies.push(...records);
  // request more pages
  fetchNextPage();
}

// call back function that is called when all pages are loaded
function gotAllMovies(err) {
  console.log("gotAllMovies()");

  // report an error, you'd want to do something better than this in production
  if (err) {
    console.log("error loading movies");
    console.error(err);
    return;
  }

  // call functions to log and show the books
  consoleLogMovies();
  showMovies();
}

// just loop through the books and console.log them
function consoleLogMovies() {
  console.log("consoleLogMovies()");
  movies.forEach((movie) => {
    console.log("Movie:", movie);
  });
}


// trying to add thumbnails to scroll in fake carousel

function showMovies() {
    console.log("showMovies()");
    movies.forEach((movie) => {
let scrollContainer = document.createElement("div");
scrollContainer.classList.add("movie-holder");
container.appendChild(scrollContainer);

let imageHolder = document.createElement("img");
imageHolder.src = movie.fields.thumbnail[0].url;
imageHolder.classList.add ("movie-video");
movieTextHolder.appendChild(imageHolder);
    })}